println("starting")
include("load_ClaDS2_functions.jl")
println("started")
include("mcmc_ClaDS2_options.jl")
include("load_ETR2.jl")
#include("ClaDS2_enhance_ETR_try.jl")



alphas = LogNormal(-0.05, 0.1)
sigmas = InverseGamma(0.5, 0.05)#Uniform(0,1)
turnover = Uniform(0,1)
means = LogNormal(-0.0, 0.1)

λ0 = 0.1
n_tips = parse(Int64,ARGS[4])
i = parse(Int64,ARGS[1])
ini = parse(Int64,ARGS[2])
end_i = parse(Int64,ARGS[3])

i += 0
i *= 10

for sampling_fraction in [1., 0.9, 0.5]
    f_name = Int64(round(sampling_fraction*10))

    for j in ini:end_i
        seed = i + j
        file_name = "ETR2-h0_r1_e10_m50_f$(f_name)_$(n_tips)_$seed"
        if  false | !isfile("/data/biodiv/maliet/ClaDS_Julia/h_etr/sim_$n_tips/$(file_name)-Julia.jld2")
            println("$n_tips tips, seed = $seed")
            Random.seed!(seed)


            ε = rand(turnover)
            σ = sqrt(rand(sigmas))
            #alphas = LogNormal(-(σ^2/2), 0.5)

            #mean_rate = rand(means)
            #mean_rate = rand(means)
            α = rand(alphas)#
            mean_rate =α * exp(σ^2/2)

            println(" ")
            println("$i ; σ = $σ, α = $α, ε = $ε ; seed = $seed")

            seed = seed
            tip_full = Int64(round(n_tips/sampling_fraction))

            Random.seed!(seed)
            complete_tree = sim_ClaDS2_ntips(tip_full,σ,α,ε,λ0, prune_extinct = false)
            pruned_tree = root_tree(complete_tree)
            println(minimum(extract_branch_lengths(pruned_tree)[2:end]))
            if mean_rate < 4  && (minimum(extract_branch_lengths(pruned_tree)[2:end]) > 1e-10)

                extant_tree, tip_rates = sample_tips_tipRates(pruned_tree, sampling_fraction, root_age = true)
                speciation_rates = extract_rates(extant_tree)

                R"par(mfrow=c(1,2))"
                plot_ClaDS(extant_tree)
                plot_ClaDS(complete_tree)


                Random.seed!(813)
                n_iter = 500

                sampler = run_ClaDS_ETR2(extant_tree, n_iter, print_state = 100, max_node_number = 50, thin = 1, burn = 0.1,max_try = 1,
                    it_edge_tree = 10, it_rates = 1, enhance_method = "MHrr",plot_chain = false,plot_tree=0, f=sampling_fraction,
                    end_it = 100_000, initialize_rates = 0)

                chains_to_R_coda(sampler[1][1] , save_chain = true, file = "/data/biodiv/maliet/ClaDS_Julia/h_etr/sim_$n_tips/$(file_name)-codaChains.Rdata",
                    max_it_number = 2_500)

                pruned_tree = root_tree(complete_tree)
                sim_ltt = LTT(pruned_tree, sampler[1][6])[2]
                n_extant = n_extant_tips(pruned_tree)
                n_extinct = n_tip(pruned_tree) - n_extant

                # result = (sim_ltt, extant_tree, ((ltt_times),maps, gelma), σ, α, ε, λ0, n_tips, seed, n_extant, n_extinct)
                result = (sim_ltt, extant_tree, ((sampler[1][6]),sampler[2], sampler[3]), σ, α, ε, λ0, n_tips, seed, n_extant, n_extinct, tip_rates)
                @save "/data/biodiv/maliet/ClaDS_Julia/h_etr/sim_$n_tips/$(file_name)-Julia.jld2" result
                #@load "/data/biodiv/maliet/ClaDS_Julia/result_MH/sim_$n_tips/$(file_name)-Julia.jld2" result
            end
        end
    end
end

    println("done")
