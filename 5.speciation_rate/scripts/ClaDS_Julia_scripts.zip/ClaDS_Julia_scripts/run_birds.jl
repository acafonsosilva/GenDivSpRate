include("load_ClaDS2_functions.jl")
reval("""library(RPANDA)
    tree_full=read.nexus("~/Documents/ENS/Taux/Hacket_MCC_100_CAT.nex")""")

@rget tree_full

tree = ape2Tree(tree_full)
plot_ClaDS(rasterize(tree), show_labels = false, options = ",type='p'")
println("started")

reval("""
        load("~/Documents/ClaDS_Julia/empirical/birds_fs.Rdata")
        f_tips = c()
        for (sp in tree_full[[4]]){
            if ( !sp %in% species_samplingFrac[,2]){
                f_tips = c(f_tips,1)
            }else{
                f_tips = c(f_tips,species_samplingFrac[which(species_samplingFrac[,2]==sp),3])
            }
        }
    """)
@rget f_tips
fs = sample_fractions_allDeep(tree, f_tips)[2:end] # to have 1. as a sampling fraction in the backbone tree.
# if you want to use the weighted mean instead do
#fs = f_tips

plot_ClaDS(tree,fs, ln = false)
R"par(mfrow=c(1,1))"

Random.seed!(813)
n_iter = 10
id = 12
burn = 0.25
iet = 10
ir = 1
th = 10
mi = 10_000

sampler = run_ClaDS2(tree, 10, print_state = 1, max_node_number = 100,
    burn = burn,max_try = mi,
    it_edge_tree = iet, it_rates = ir,
    thin = th, f=fs,
    enhance_method = "MHrr",plot_chain = true,save_as_R=true,Rfile="~/Documents/ClaDS_Julia/empirical/birds_MHR_fsad.Rdata",
    plot_tree=1, goal_gelman = 0., end_it = 10, initialize_rates = 0)

R"par(mfrow=c(2,1))"
plot_time_rates_mcmc(tree, sampler)
plot_ClaDS(tree, map(exp, sampler[2][5:(tree.n_nodes+3)]))              # the rates

npar = tree.n_nodes + 3

while sampler[3][2] > 1.05
    global sampler = run_ClaDS2(tree, 100, print_state = 25, max_node_number = 100,
        burn = burn,max_try = mi,
        it_edge_tree = iet, it_rates = ir,
        thin = th, f=fs,
        enhance_method = "MHrr",sampler=sampler[1],
        plot_chain = true,save_as_R=true,Rfile="~/Documents/ClaDS_Julia/empirical/birds_MHR_fsad.Rdata",
        plot_tree=100, goal_gelman = 1.05, end_it = 500, initialize_rates = 0)

    println("ploting")

    reval("""
        pdf("/Users/maliet/Documents/ClaDS_Julia/birds_fsad.pdf", width = 12, height = 10)
    """)
    plot_coda(sampler[1], burn = burn)                                  # the chain
    R"par(mfrow=c(2,2))"
    plot_time_rates_mcmc(tree, sampler, burn = burn)
    plot_LTT_chain(sampler, tree, 12_000, n_ltt = 100)
    plot_LTT_chain_extinct(sampler, tree, 3500 , n_ltt = 100)
    plot_ClaDS(tree, map(exp, sampler[2][5:(tree.n_nodes+3)]))
    ni = length(sampler[1][1][1][1])
    @rput ni
    R"title(main=ni)"             # the rates
    R"par(mfrow=c(1,1))"
    plot_ClaDS(tree, map(exp, sampler[2][5:(tree.n_nodes+3)]), round = true)              # the rates
    R"dev.off()"

    n_extant_tips(tree)
    result = (tree, sampler, f_tips)
    @save "/Users/maliet/Documents/Julia_ClaDS/bird_MHR_fsad.jld2" result
end
