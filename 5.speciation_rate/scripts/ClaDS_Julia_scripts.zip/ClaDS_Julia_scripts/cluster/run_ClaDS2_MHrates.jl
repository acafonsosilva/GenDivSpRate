println("starting")
include("load_ClaDS2_functions.jl")
println("started")
include("update_edges_2.jl")


means = LogNormal(0, 0.1)
sigmas = Uniform(0,1)
turnover = Uniform(0,1)

λ0 = 0.1
n_tips = parse(Int64,ARGS[4])
i =  parse(Int64,ARGS[1])
ini = parse(Int64,ARGS[2])
end_i = parse(Int64,ARGS[3])

i += 0
i *= 10

for j in ini:end_i
    seed = i + j
    file_name = "ClaDS2_MHR_$(n_tips)_$seed"
    if !isfile("/data/biodiv/maliet/ClaDS_Julia/result_MHrates/sim_$n_tips/$(file_name)-Julia.jld2")
        println("$n_tips tips, seed = $seed")
        Random.seed!(seed)

        ε = rand(turnover)
        σ = rand(sigmas)
        mean_rate = rand(means)
        α = mean_rate / exp(σ^2/2)


        println(" ")
        println("$i ; σ = $σ, α = $α, ε = $ε ; seed = $seed")

        seed = seed

        Random.seed!(seed)
        tree, complete_tree, times, n_lineages, end_time = sim_ClaDS2_ntips(n_tips,σ,α,ε,λ0, prune_extinct = false)
        Random.seed!(seed)
        tree, extant_tree, times, n_lineages, end_time = sim_ClaDS2_ntips(n_tips,σ,α,ε,λ0, prune_extinct = true)
        speciation_rates = extract_rates(extant_tree)
        if extant_tree.n_nodes == (2*n_tips - 1)
            Random.seed!(813)
            n_iter = 400
            
            tip_rates = extract_tip_rates(complete_tree, return_extinct = false)

            sampler = run_ClaDS_LTT(extant_tree, n_iter, print_state = 100, max_node_number = 5_000, thin = 10, it_edge_tree = 1, it_rates = 1, enhance_method = "MHrates",plot_chain = true,plot_tree=100)

            chains_to_R_coda(sampler[1][1] , save_chain = true, file = "/data/biodiv/maliet/ClaDS_Julia/result_MHrates/sim_$n_tips/$(file_name)-codaChains.Rdata",
                max_it_number = 2_500)

            pruned_tree = root_tree(complete_tree)
            sim_ltt = LTT(pruned_tree, sampler[1][6])[2]
            n_extant = n_extant_tips(pruned_tree)
            n_extinct = n_tip(pruned_tree) - n_extant

            # result = (sim_ltt, extant_tree, ((ltt_times),maps, gelma), σ, α, ε, λ0, n_tips, seed, n_extant, n_extinct)
            result = (sim_ltt, extant_tree, ((sampler[1][6]),sampler[2], sampler[3]), σ, α, ε, λ0, n_tips, seed, n_extant, n_extinct, tip_rates)
            @save "/data/biodiv/maliet/ClaDS_Julia/result_MHrates/sim_$n_tips/$(file_name)-Julia.jld2" result
            #@load "/data/biodiv/maliet/ClaDS_Julia/result_MH/sim_$n_tips/$(file_name)-Julia.jld2" result
        end
    end
end

println("done")
