universe = vanilla
executable = /bin/bash
error = /data/biodiv/maliet/ClaDS_Julia/log/e$(Cluster)_$(Process).txt
output = /data/biodiv/maliet/ClaDS_Julia/log/o$(Cluster)_$(Process).txt
log = /data/biodiv/maliet/ClaDS_Julia/log/log$(Cluster)_$(Process).txt
arguments = ./run_with_args.sh run_ClaDS2_MHlong.jl $(Process) 0 10 100
notification = Never
request_cpus = 1
request_memory = 6G
nice_user = TRUE
Queue 10
