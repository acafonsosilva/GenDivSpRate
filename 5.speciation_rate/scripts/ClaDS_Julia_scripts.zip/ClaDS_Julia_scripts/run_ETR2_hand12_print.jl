println("starting")
include("load_ClaDS2_functions.jl")
println("started")
include("load_ETR2.jl")
#include("ClaDS2_enhance_ETR_try.jl")

try_again = 20

alphas = LogNormal(-0.05, 0.1)
sigmas = InverseGamma(0.5, 0.05)#Uniform(0,1)
turnover = Uniform(0,1)
means = LogNormal(-0.0, 0.1)

λ0 = 0.1
n_tips = parse(Int64,ARGS[4])
i = parse(Int64,ARGS[1])
ini = parse(Int64,ARGS[2])
end_i = parse(Int64,ARGS[3])
p = parse(Int64,ARGS[5])

i += 0
i *= 10

id = 12
burn = 0.25
iet = 1
ir = 10
th = 100
mi = 10_000
quad = 5

if !isdir("/data/biodiv/maliet/ClaDS_Julia/h_etr/sim_$n_tips/h$(id)/")
    mkdir("/data/biodiv/maliet/ClaDS_Julia/h_etr/sim_$n_tips/h$(id)/")
end

for sampling_fraction in [1., 0.9, 0.5]
    f_name = Int64(round(sampling_fraction*10))

    for j in ini:end_i
        seed = i + j
        file_name = "ETR2-h$(id)_r$(ir)x$(th)_e$(iet)x$(mi)_q$(quad)_m100_f$(f_name)_$(n_tips)_$seed"
        if  !isfile("/data/biodiv/maliet/ClaDS_Julia/h_etr/sim_$n_tips/h$(id)/$(file_name)-Julia.jld2") & !isfile("/data/biodiv/maliet/ClaDS_Julia/h_etr/sim_$n_tips/$(file_name)-Julia.jld2")
            println("$n_tips tips, seed = $seed")
            Random.seed!(seed)

            ε = 0
            σ = 0
            α = 0
            mean_rate = 10

            while mean_rate > 4
                ε = rand(turnover)
                σ = sqrt(rand(sigmas))
                α = rand(alphas)#
                mean_rate =α * exp(σ^2/2)
            end


            println(" ")
            println("$i ; σ = $σ, α = $α, ε = $ε ; seed = $seed")

            seed = seed
            tip_full = Int64(round(n_tips/sampling_fraction))
            sim_tree = 0
            bl = 0

            complete_tree = Tree()
            pruned_tree = Tree()

            Random.seed!(seed)

            while (bl < 1e-10) && (sim_tree < try_again) && (mean_rate < 4)
                sim_tree += 1
                complete_tree = sim_ClaDS2_ntips(tip_full,σ,α,ε,λ0, prune_extinct = false)
                println(complete_tree.n_nodes)
                if complete_tree.n_nodes > 1
                    pruned_tree = root_tree(complete_tree)
                    bl = minimum(extract_branch_lengths(pruned_tree)[2:end])
                end
            end

            if mean_rate < 4  && (bl > 1e-10)

                extant_tree, tip_rates = sample_tips_tipRates(pruned_tree, sampling_fraction, root_age = true)
                speciation_rates = extract_rates(extant_tree)


                Random.seed!(813)
                n_iter = 50

                sampler = run_ClaDS_ETR2(extant_tree, n_iter, print_state = p, max_node_number = 100, thin = th, burn = burn,max_try = mi,
                    it_edge_tree = iet, it_rates = ir, enhance_method = "MHrr",plot_chain = false,plot_tree=0, f=sampling_fraction, quad = quad,
                    end_it = 100_000, initialize_rates = 0, n_chains = 3)

                chains_to_R_coda(sampler[1][1] , save_chain = true, file = "/data/biodiv/maliet/ClaDS_Julia/h_etr/sim_$n_tips/h$(id)/$(file_name)-codaChains.Rdata",
                    max_it_number = 200, burn = burn)

                pruned_tree = root_tree(complete_tree)
                sim_ltt = LTT(pruned_tree, sampler[1][6])[2]
                n_extant = n_extant_tips(pruned_tree)
                n_extinct = n_tip(pruned_tree) - n_extant

                # result = (sim_ltt, extant_tree, ((ltt_times),maps, gelma), σ, α, ε, λ0, n_tips, seed, n_extant, n_extinct)
                result = (sim_ltt, extant_tree, ((sampler[1][6]),sampler[2], sampler[3]), σ, α, ε, λ0, n_tips, seed, n_extant, n_extinct, tip_rates)
                @save "/data/biodiv/maliet/ClaDS_Julia/h_etr/sim_$n_tips/h$(id)/$(file_name)-Julia.jld2" result
                #@load "/data/biodiv/maliet/ClaDS_Julia/result_MH/sim_$n_tips/$(file_name)-Julia.jld2" result
            end
        end
    end
end

    println("done")
