using Pkg

Pkg.add("RCall")
Pkg.add("StatsBase")
Pkg.add("Distributions")
Pkg.add("Random")
Pkg.add("BenchmarkTools")
Pkg.add("JLD2")
