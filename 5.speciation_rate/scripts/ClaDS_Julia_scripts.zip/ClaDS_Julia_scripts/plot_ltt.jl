include("load_ClaDS2_functions.jl")
include("load_ETR2.jl")
function extractNplotLTT_Rdata2(file_name, folder, n_tips, Is, plot_name ; add = false, multi_page = false, n_ltt = 100, alpha_col = 0.05, plot_HP = true)
    reval("""
        data = data.frame()
    """)

    @rput plot_name

    if multi_page
        reval(""" pdf(file = paste0("/Users/maliet/Documents/ClaDS_Julia/lateX/",
            plot_name,"_full.pdf"), width = 10, height = 10)""")
    end

    @rput file_name
    missing = 0

    if add
        reval("""
            try(load(paste0("~/ownCloud/My_folder/ClaDS/Rdata/data_", file_name, ".Rdata")))
        """)
    end

    for k in 1:length(n_tips)
        for i in Is[k]
            print("$i ")
            nt = n_tips[k]
            file_string_jl = "/Users/maliet/Documents/Julia_ClaDS/$folder/sim_$nt/$file_name$(nt)_$i-Julia.jld2"
            file_string_R = "/Users/maliet/Documents/Julia_ClaDS/$folder/sim_$nt/$file_name$(nt)_$i-codaChains.Rdata"

            @rput nt
            @rput i

            reval("""
                eval = T
                if(nrow(data)>1){
                    eval = (sum(data[,"n"]==nt  & data[,"seed"] ==i) == 0)
                    }
            """)
            @rget eval

            if eval & isfile(file_string_jl)
                @load file_string_jl result

                if !multi_page
                    reval("""
                        pdf(file = paste0("/Users/maliet/ownCloud/My_folder/ClaDS_Julia_list_of_lists/ltt/plot/",
                            plot_name,"_",nt,"_",i,".pdf"), width = 10, height = 10)
                    """)
                end

                MAPS = result[3][2]
                sig = result[4]
                al = result[5]
                eps = result[6]
                lamb0 = result[7]
                seed = result[9]
                speciation_rates = map(log, extract_rates(result[2]))
                tip_rates = map(log, result[12])
                npar_plot = result[2].n_nodes + 3
                ntips = (result[2].n_nodes+1)/2
                chains = R_coda_to_chains(file_string_R)
                n_it = size(chains[1][1])[1]
                tips_id = tips(result[2])[2:end]
                @rput MAPS
                @rput sig
                @rput al
                @rput eps
                @rput lamb0
                @rput seed
                @rput speciation_rates
                @rput npar_plot
                @rput tip_rates
                @rput ntips
                @rput n_it
                @rput tips_id

                reval("""
                    layout(matrix(c(1,1,1,2,3,3,2,4,5,c(4,7,8,5,7,8,6,7,8)+2),ncol = 3, byrow = T), height = 2*c(0.5,1.5,1.5,1,1,1), width = c(2,1,1))
                    par(mar = c(0,0,0,0))
                    plot(10000, xlim = c(0,1), ylim = c(0,1), axes = F)
                    text(x = 0.5,y = 0.5,labels = paste0(i," __ ",nt,
                        " tips ; sigma = ",round(sig,2),
                        " ; alpha = ",round(al,2),
                        " ; epsilon = ",round(eps,2)), cex = 2.5)
                    par(mar = c(4.5,4.5,2,2))
                """)

                plot_LTT_chain(chains, result[1],result[2], 2 * result[8], result[3][1], MAPS, n_ltt = n_ltt, alpha_col = alpha_col)
                plot_LTT_chain_extinct(chains, result[1],result[2], result[8]/2, result[3][1], MAPS, n_ltt = n_ltt, alpha_col = alpha_col)


                reval("""
                sigma_quant = quantile(unlist_chains[,1], probs = c(0.05,0.95))
                alpha_quant = quantile(unlist_chains[,2], probs = c(0.05,0.95))
                epsilon_quant = quantile(unlist_chains[,3], probs = c(0.05,0.95))

                iter = 5:npar_plot
                tip_rates = tip_rates[!is.nan(tip_rates)]
                tips = (npar_plot+1):(npar_plot+ntips)
                #print(length(tips))
                #print((tip_rates))
                lm = lm(MAPS[iter] ~ speciation_rates[-1])
                lm_tips = lm(MAPS[tips] ~ tip_rates)
                lm_tips_li = lm(MAPS[iter][tips_id] ~ tip_rates)
                plot(speciation_rates[-1], MAPS[iter], pch = 20)
                abline(0, 1, lwd = 3, col = "orange")
                abline(lm[[1]][1], lm[[1]][2], lwd = 3, col = "darkslategray4")

                plot(tip_rates, MAPS[tips], pch = 20, ylim = range(c(MAPS[iter][tips_id], MAPS[tips])))
                points(tip_rates, MAPS[iter][tips_id], pch = 21)
                abline(0, 1, lwd = 3, col = "orange")
                abline(lm_tips_li[[1]][1], lm_tips_li[[1]][2], lwd = 3, col = "darkslategray4", lty = 3)
                abline(lm_tips[[1]][1], lm_tips[[1]][2], lwd = 3, col = "darkslategray4")

                densplot(mcmc(unlist_chains[,1]))
                abline(v = sig,lwd=3, col = "orange")
                abline(v = MAPS[1],lwd=3, col = "darkslategray4")
                densplot(mcmc(unlist_chains[,2]))
                abline(v = al,lwd=3, col = "orange")
                abline(v = MAPS[2],lwd=3, col = "darkslategray4")
                densplot(mcmc(unlist_chains[,3]))
                abline(v = eps,lwd=3, col = "orange")
                abline(v = MAPS[3],lwd=3, col = "darkslategray4")

                par(mar = c(2,0,2,6))
                """)

                plot_ClaDS(result[2], map(exp,speciation_rates[2:end]), map(exp,MAPS[[5:npar_plot...]]))
                #n_extant = n_extant_tips(result[1])
                #n_extinct = n_tip(result[1]) - n_extant
                #@rput n_extinct
                #@rput n_extant

                reval("""
                data = rbind(data, data.frame(n = nt, sigma = sig, alpha = al, epsilon = eps, lambda_0 = lamb0, m = al * exp(sig^2 / 2),
                    sigma_inf = MAPS[1], alpha_inf = MAPS[2], epsilon_inf = MAPS[3], m_inf = MAPS[2] * exp(MAPS[1]^2 / 2),
                    cor = cor(speciation_rates[-1], MAPS[iter]), rel_error = exp(mean(MAPS[iter] - speciation_rates[-1])),
                    slope = lm[[1]][2], cor_ext_mean = cor((means[id_ltt] - live_ltt), (sim_ltt - live_ltt)),
                    slope_tips = lm_tips[[1]][2], cor_tips = cor(MAPS[tips], tip_rates),
                    rel_error_tips = exp(mean(MAPS[tips]-tip_rates)),
                    mse_tips = sqrt(mean((MAPS[tips]-tip_rates)^2)),
                    slope_tips_li = lm_tips[[1]][2], cor_tips_li = cor(MAPS[iter][tips_id], tip_rates),
                    rel_error_tips_li = exp(mean(MAPS[iter][tips_id]-tip_rates)),
                    mse_tips_li = sqrt(mean((MAPS[iter][tips_id]-tip_rates)^2)),
                    cor_ext_maps = cor((maps[id_ltt] - live_ltt), (sim_ltt - live_ltt)),
                    seed = seed, n_it = n_it, n_out = n_out,
                    sigma_05 = sigma_quant[1], sigma_95 = sigma_quant[2],
                    alpha_05 = alpha_quant[1], alpha_95 = alpha_quant[2],
                    epsilon_05 = epsilon_quant[1], epsilon_95 = epsilon_quant[2]))
                save(data,file = paste0("~/ownCloud/My_folder/ClaDS/Rdata/data_", file_name, ".Rdata"))
                """)

                if !multi_page
                    R" dev.off()"
                end

            elseif ! isfile(file_string_jl)
                missing += 1
                println("missing file for $file_string_jl")
            end

        end
    end
    if multi_page
        @rput file_name
        reval("""
            source("~/ownCloud/My_folder/ClaDS/run_Rplot_ext.R")
        """)

        string = """par(mfrow = c(2,2))
        plot(data\$slope_tips,data\$slope_tips_li, col = cols[data\$order], pch = 20, cex = 2)
        polygon(c(-10,1,1),c(-10,-10,1),col ="gray95", border = NA)
        points(data\$slope_tips,data\$slope_tips_li, col = cols[data\$order], pch = 20, cex = 2)

        plot(data\$rel_error_tips,data\$rel_error_tips_li, col = cols[data\$order], pch = 20, cex = 2)
        polygon(c(1,10,-10),c(1,10,10),col ="gray95", border = NA)
        polygon(c(1,10,-10),c(1,-10,-10),col ="gray95", border = NA)
        points(data\$rel_error_tips,data\$rel_error_tips_li, col = cols[data\$order], pch = 20, cex = 2)

        plot(data\$mse_tips,data\$mse_tips_li, col = cols[data\$order], pch = 20, cex = 2)
        polygon(c(-10,-10,10),c(-10,10,10),col ="gray95", border = NA)
        points(data\$mse_tips,data\$mse_tips_li, col = cols[data\$order], pch = 20, cex = 2)

        plot(data\$cor_tips,data\$cor_tips_li, col = cols[data\$order], pch = 20, cex = 2)
        polygon(c(-10,10,10),c(-10,-10,10),col ="gray95", border = NA)
        points(data\$cor_tips,data\$cor_tips_li, col = cols[data\$order], pch = 20, cex = 2)

            """
        reval(string)
        R" dev.off()"
    end

    if plot_HP
        @rput file_name
        reval("""
            print("enter")
            pdf(file = paste0("/Users/maliet/Documents/ClaDS_Julia/lateX/",
            plot_name,"_HP.pdf"), width = 10, height = 10)
            source("~/ownCloud/My_folder/ClaDS/run_Rplot_ext.R")
            print("exit")
        """)
        R" dev.off()"
    end
    println("Still $missing files missing")
end

function extractNplotLTT_Rdata(file_name, folder, n_tips, Is, Fs, plot_name ; add = false, multi_page = false,
    n_ltt = 100, alpha_col = 0.05, plot_HP = true, alpha_pool = 0.4)
    reval("""
        data = data.frame()
    """)
    @rput alpha_pool
    @rput plot_name

    if multi_page
        reval(""" pdf(file = paste0("/Users/maliet/Documents/ClaDS_Julia/lateX/",
            plot_name,"_full.pdf"), width = 10, height = 10)""")
    end

    @rput file_name
    missing = 0

    if add
        reval("""
            try(load(paste0("~/ownCloud/My_folder/ClaDS/Rdata/data_", file_name, ".Rdata")))
        """)
    end

    for k in 1:length(n_tips)
        for f in Fs[k]
            for i in Is[k]

                print("$i ")
                nt = n_tips[k]
                file_string_jl = "/Users/maliet/Documents/Julia_ClaDS/$folder/sim_$nt/$(file_name)_f$(f)_$(nt)_$i-Julia.jld2"
                file_string_R = "/Users/maliet/Documents/Julia_ClaDS/$folder/sim_$nt/$(file_name)_f$(f)_$(nt)_$i-codaChains.Rdata"

                @rput nt
                @rput i

                reval("""
                    eval = T
                    #if(nrow(data)>1){
                    #    eval = (sum(data[,"n"]==nt  & data[,"seed"] ==i) == 0)
                    #    }
                """)
                @rget eval

                if eval & isfile(file_string_jl)
                    @load file_string_jl result

                    if !multi_page
                        reval("""
                            pdf(file = paste0("/Users/maliet/ownCloud/My_folder/ClaDS_Julia_list_of_lists/ltt/plot/",
                                plot_name,"_",nt,"_",i,".pdf"), width = 10, height = 10)
                        """)
                    end

                    MAPS = result[3][2]
                    sig = result[4]
                    al = result[5]
                    eps = result[6]
                    lamb0 = result[7]
                    seed = result[9]
                    speciation_rates = map(log, extract_rates(result[2]))
                    tip_rates = map(log, result[12])
                    npar_plot = result[2].n_nodes + 3
                    ntips = (result[2].n_nodes+1)/2
                    chains = R_coda_to_chains(file_string_R)
                    @rget it_number
                    n_it = size(chains[1][1])[1]
                    tips_id = tips(result[2])[2:end]
                    @rput MAPS
                    @rput sig
                    @rput al
                    @rput eps
                    @rput lamb0
                    @rput seed
                    @rput speciation_rates
                    @rput npar_plot
                    @rput tip_rates
                    @rput ntips
                    @rput n_it
                    @rput tips_id
                    @rput f

                    reval("""
                        layout(matrix(c(1,1,1,2,3,3,2,4,5,c(4,7,8,5,7,8,6,7,8)+2),ncol = 3, byrow = T), height = 2*c(0.5,1.5,1.5,1,1,1), width = c(2,1,1))
                        par(mar = c(0,0,0,0))
                        plot(10000, xlim = c(0,1), ylim = c(0,1), axes = F)
                        text(x = 0.5,y = 0.5,labels = paste0("f = ",f/10," ; ",i," __ ",nt,
                            " tips ; sigma = ",round(sig,2),
                            " ; alpha = ",round(al,2),
                            " ; epsilon = ",round(eps,2)), cex = 2.5)
                        par(mar = c(4.5,4.5,2,2))
                    """)

                    plot_LTT_chain(chains, result[1],result[2], 15 * result[8]/f, result[3][1], MAPS, n_ltt = n_ltt, alpha_col = alpha_col, burn = 0)
                    plot_LTT_chain_extinct(chains, result[1],result[2], result[8]/2, result[3][1], MAPS, n_ltt = n_ltt, alpha_col = alpha_col, burn = 0)


                    reval("""
                    sigma_quant = quantile(unlist_chains[,1], probs = c(0.025,0.975))
                    alpha_quant = quantile(unlist_chains[,2], probs = c(0.025,0.975))
                    epsilon_quant = quantile(unlist_chains[,3], probs = c(0.025,0.975))

                    iter = 5:npar_plot
                    tip_rates = tip_rates[!is.nan(tip_rates)]
                    #print(speciation_rates[-1][tips_id] - tip_rates)
                    tips = (npar_plot+1):(npar_plot+ntips)
                    #print(length(tips))
                    #print((tip_rates))
                    lm = lm(MAPS[iter] ~ speciation_rates[-1])
                    lm_tips = lm(MAPS[tips] ~ tip_rates)
                    lm_tips_li = lm(MAPS[iter][tips_id] ~ tip_rates)
                    plot(speciation_rates[-1], MAPS[iter], pch = 20)
                    abline(0, 1, lwd = 3, col = "orange")
                    abline(lm[[1]][1], lm[[1]][2], lwd = 3, col = "darkslategray4")

                    plot(tip_rates, MAPS[tips], pch = 20, ylim = range(c(MAPS[iter][tips_id], MAPS[tips])))
                    points(tip_rates, MAPS[iter][tips_id], pch = 21)
                    abline(0, 1, lwd = 3, col = "orange")
                    abline(lm_tips_li[[1]][1], lm_tips_li[[1]][2], lwd = 3, col = "darkslategray4", lty = 3)
                    abline(lm_tips[[1]][1], lm_tips[[1]][2], lwd = 3, col = "darkslategray4")

                    densplot(mcmc(unlist_chains[,1]))
                    abline(v = sig,lwd=3, col = "orange")
                    abline(v = MAPS[1],lwd=3, col = "darkslategray4")
                    densplot(mcmc(unlist_chains[,2]))
                    abline(v = al,lwd=3, col = "orange")
                    abline(v = MAPS[2],lwd=3, col = "darkslategray4")
                    densplot(mcmc(unlist_chains[,3]))
                    abline(v = eps,lwd=3, col = "orange")
                    abline(v = MAPS[3],lwd=3, col = "darkslategray4")

                    par(mar = c(2,0,2,6))
                    """)

                    plot_ClaDS(result[2], map(exp,speciation_rates[2:end]), map(exp,MAPS[[5:npar_plot...]]))
                    #n_extant = n_extant_tips(result[1])
                    #n_extinct = n_tip(result[1]) - n_extant
                    #@rput n_extinct

                    reval("""
                    data = rbind(data, data.frame(n = nt, sigma = sig, alpha = al, epsilon = eps,
                        lambda_0 = lamb0, m = al * exp(sig^2 / 2), sampling_fraction = f/10,
                        sigma_inf = MAPS[1], alpha_inf = MAPS[2], epsilon_inf = MAPS[3], m_inf = MAPS[2] * exp(MAPS[1]^2 / 2),
                        cor = cor(speciation_rates[-1], MAPS[iter]), rel_error = exp(mean(MAPS[iter] - speciation_rates[-1])),
                        slope = lm[[1]][2], cor_ext_mean = cor((means[id_ltt] - live_ltt), (sim_ltt - live_ltt)),
                        Rsquared = summary(lm)[[8]],
                        slope_tips = lm_tips[[1]][2], cor_tips = cor(MAPS[tips], tip_rates),
                        Rsquared_tips = summary(lm_tips)[[8]],
                        rel_error_tips = exp(mean(MAPS[tips]-tip_rates)),
                        mse_tips = sqrt(mean((MAPS[tips]-tip_rates)^2)),
                        slope_tips_li = lm_tips_li[[1]][2], cor_tips_li = cor(MAPS[iter][tips_id], tip_rates),
                        rel_error_tips_li = exp(mean(MAPS[iter][tips_id]-tip_rates)),
                        Rsquared_tips_li = summary(lm_tips_li)[[8]],
                        mse_tips_li = sqrt(mean((MAPS[iter][tips_id]-tip_rates)^2)),
                        cor_ext_maps = cor((maps[id_ltt] - live_ltt), (sim_ltt - live_ltt)),
                        seed = seed, n_it = n_it, n_out = n_out,
                        sigma_05 = sigma_quant[1], sigma_95 = sigma_quant[2],
                        alpha_05 = alpha_quant[1], alpha_95 = alpha_quant[2],
                        epsilon_05 = epsilon_quant[1], epsilon_95 = epsilon_quant[2],
                        it_number = it_number))
                    save(data,file = paste0("~/ownCloud/My_folder/ClaDS/Rdata/data_", file_name, ".Rdata"))
                    """)

                    if !multi_page
                        R" dev.off()"
                    end

                elseif ! isfile(file_string_jl) & isfile(file_string_R)
                    try_again = 20
                    sampling_fraction = f * 0.1
                    λ0 = 0.1
                    alphas = LogNormal(-0.05, 0.1)
                    sigmas = InverseGamma(0.5, 0.05)#Uniform(0,1)
                    turnover = Uniform(0,1)
                    means = LogNormal(-0.0, 0.1)
                    seed = i

                    println("$nt tips, seed = $seed")
                    Random.seed!(seed)

                    ε = 0
                    σ = 0
                    α = 0
                    mean_rate = 10

                    while mean_rate > 4
                        print("$ε ")
                        ε = rand(turnover)
                        σ = sqrt(rand(sigmas))
                        α = rand(alphas)#
                        mean_rate =α * exp(σ^2/2)
                    end


                    println(" ")
                    println("$i ; σ = $σ, α = $α, ε = $ε ; seed = $seed")

                    tip_full = Int64(round(nt/sampling_fraction))
                    sim_tree = 0
                    bl = 0

                    complete_tree = Tree()
                    pruned_tree = Tree()

                    Random.seed!(seed)

                    while (bl < 1e-10) && (sim_tree < try_again) && (mean_rate < 4)
                        sim_tree += 1
                        complete_tree = sim_ClaDS2_ntips(tip_full,σ,α,ε,λ0, prune_extinct = false)
                        println(complete_tree.n_nodes)
                        if complete_tree.n_nodes > 1
                            pruned_tree = root_tree(complete_tree)
                            bl = minimum(extract_branch_lengths(pruned_tree)[2:end])
                        end
                    end

                    if mean_rate < 4  && (bl > 1e-10)

                        extant_tree, tip_rates = sample_tips_tipRates(pruned_tree, sampling_fraction, root_age = true)
                        speciation_rates = extract_rates(extant_tree)
                        println(speciation_rates)
                        plot_ClaDS(extant_tree)

                        new_tree = Tree(deepcopy(pruned_tree.offsprings), 0., deepcopy(pruned_tree.attributes))
                        root_depth = maximum(node_depths(new_tree)) * 1.01
                        ltt_steps = 50
                        ltt_times = [0:ltt_steps...] * root_depth/ltt_steps
                        sim_ltt = LTT(pruned_tree, ltt_times)[2]
                        n_extant = n_extant_tips(pruned_tree)
                        n_ti = n_extant_tips(extant_tree)
                        n_extinct = n_tip(pruned_tree) - n_extant
                        npar = extant_tree.n_nodes + 3
                        @rput npar
                        @rput n_ti
                        @rput file_string_R
                        reval("""
                            load(file_string_R)
                            nr = nrow(coda_chain[[1]])
                            rows=floor(nr/10):nr
                            npar2 = ncol(coda_chain[[1]])
                            unlist_chains = sapply(1:npar2, function(k){
                                if(k<4 || k>(npar+n_ti)) {
                                    c(coda_chain[[1]][rows,k], coda_chain[[2]][rows,k], coda_chain[[3]][rows,k])
                                    }else{
                                    log(c(coda_chain[[1]][rows,k], coda_chain[[2]][rows,k], coda_chain[[3]][rows,k]))
                                    }
                                })
                            MAPS=sapply(1:npar2, function(i){D=density(unlist_chains[,i]);
                                    return(D[[1]][which.max(D[[2]])])})
                            """)
                        @rget MAPS
                        result = (sim_ltt, extant_tree, (ltt_times,MAPS, NaN), σ, α, ε, λ0, n_tips[1], seed, n_extant, n_extinct, tip_rates)
                        @save file_string_jl result
                    end
                elseif ! isfile(file_string_jl)
                    missing += 1
                    println("missing file for $file_string_jl")
                end
            end
        end
    end
    if multi_page
        @rput file_name
        reval("""
            source("~/ownCloud/My_folder/ClaDS/run_Rplot_ext_fvar.R")
        """)

        string = """par(mfrow = c(2,2))
        pch = 15+as.integer(as.factor(data_full\$sampling_fraction))

        plot(data\$slope_tips,data\$slope_tips_li, col = cols[data\$order], pch = pch, cex = 2)
        polygon(c(1,10,-10),c(1,10,12),col ="gray95", border = NA)
        polygon(c(1,10,-10),c(1,-9,-10),col ="gray95", border = NA)
        points(data\$slope_tips,data\$slope_tips_li, col = cols[data\$order], pch = pch, cex = 2)

        plot(data\$rel_error_tips,data\$rel_error_tips_li, col = cols[data\$order], pch = pch, cex = 2)
        polygon(c(1,100,-100),c(1,100,102),col ="gray95", border = NA)
        polygon(c(1,100,-100),c(1,-99,-100),col ="gray95", border = NA)
        points(data\$rel_error_tips,data\$rel_error_tips_li, col = cols[data\$order], pch = pch, cex = 2)

        plot(data\$mse_tips,data\$mse_tips_li, col = cols[data\$order], pch = pch, cex = 2)
        polygon(c(-100,-100,100),c(-100,100,100),col ="gray95", border = NA)
        points(data\$mse_tips,data\$mse_tips_li, col = cols[data\$order], pch = pch, cex = 2)

        plot(data\$cor_tips,data\$cor_tips_li, col = cols[data\$order], pch = pch, cex = 2)
        polygon(c(-10,10,10),c(-10,-10,10),col ="gray95", border = NA)
        points(data\$cor_tips,data\$cor_tips_li, col = cols[data\$order], pch = pch, cex = 2)

            """
        reval(string)
        R" dev.off()"
    end

    if plot_HP
        @rput file_name
        reval("""
            pdf(file = paste0("/Users/maliet/Documents/ClaDS_Julia/lateX/",
            plot_name,"_tipRates.pdf"), width = 10, height = 10)
        """)
        reval(string)
        R" dev.off()"
    end

    if plot_HP
        @rput file_name
        reval("""
            pdf(file = paste0("/Users/maliet/Documents/ClaDS_Julia/lateX/",
            plot_name,"_HP.pdf"), width = 10, height = 10)
            source("~/ownCloud/My_folder/ClaDS/run_Rplot_ext.R")
        """)
        R" dev.off()"
    end
    println("Still $missing files missing")
    return missing
end


Fs = [5,9,10]

extractNplotLTT_Rdata("ETR2-h12_r10x100_e1x10000_q5_m100", "result_etr/hand", [500,200,100,50], [[0:100...],[0:100...],[0:499...],[0:499...]],
    [Fs,Fs,Fs,Fs],
    "ETR_12", add = false, multi_page = true, n_ltt = 50, alpha_col = 0.02) # <3

extractNplotLTT_Rdata("ETR2-h13_r10x100_e1x1_q5_m100", "result_etr/hand", [500,200,100,50], [[0:100...],[0:100...],[0:499...],[0:499...]],
    [Fs,Fs,Fs,Fs],
    "ETR_13", add = false, multi_page = true, n_ltt = 50, alpha_col = 0.02) # <3

extractNplotLTT_Rdata("ETR2-h14_r1x100_e1x1_q5_m100", "result_etr/hand", [500,200,100,50], [[0:100...],[0:100...],[0:499...],[0:499...]],
    [Fs,Fs,Fs,Fs],
    "ETR_14", add = false, multi_page = true, n_ltt = 50, alpha_col = 0.02) # <3
