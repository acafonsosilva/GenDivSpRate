include("load_ClaDS2_functions.jl")
reval("""library(RPANDA)
    library(coda)
    tree_full=read.nexus("/data/biodiv/maliet/ClaDS_Julia/Hacket_MCC_100_CAT.nex")""")
@rget tree_full ;
tree = ape2Tree(tree_full) ;

reval("""
        load("/data/biodiv/maliet/ClaDS_Julia/birds_fs.Rdata")
        f_tips = c()
        for (sp in tree_full[[4]]){
            if ( !sp %in% species_samplingFrac[,2]){
                f_tips = c(f_tips,1)
            }else{
                f_tips = c(f_tips,species_samplingFrac[which(species_samplingFrac[,2]==sp),3])
            }
        }
    """)
@rget f_tips ;

Random.seed!(1) ;

sampler = run_ClaDS_LTT(tree, 500, print_state = 0, max_node_number = 200,
    thin = 10, it_edge_tree = 1, it_rates = 1, f=f_tips, max_it_number = 2_500,
    enhance_method = "MHrates",plot_chain = false,save_as_R=true,Rfile="/data/biodiv/maliet/ClaDS_Julia/empirical/birds_MHR_fs.Rdata",
    plot_tree=0, goal_gelman = 0., end_it = 100_000, initialize_rates = 1000) ;

#result = (tree, sampler, f_tips)
#@save "/Users/maliet/Documents/Julia_ClaDS/bird1.jld2" result
