println("starting")
include("load_ClaDS2_functions.jl")
println("started")
include("load_ETR2.jl")
#include("ClaDS2_enhance_ETR_try.jl")

reval("""library(RPANDA)
    tree = read.tree("~/Documents/ClaDS_Julia/Julien/tree.tre")""")
@rget tree
tree = ape2Tree(tree)
sampling_fraction = 0.65

id = 14
burn = 0.25
iet = 1
ir = 1
th = 100
mi = 1
quad = 5

Random.seed!(813)
n_iter = 50

sampler = run_ClaDS2(tree, n_iter, print_state = 25, max_node_number = 100, thin = th, burn = burn,max_try = mi,
    it_edge_tree = iet, it_rates = ir, enhance_method = "MHrr",plot_chain = true,plot_tree= 50, f=sampling_fraction, quad = quad,
    end_it = 100_000, initialize_rates = 0, n_chains = 3)

chains_to_R_coda(sampler[1][1] , save_chain = true, file = "~/Documents/ClaDS_Julia/Julien/Cl2_jl.Rdata",
    max_it_number = Inf, burn = burn)
sampler_to_Rdata(tree, sampler, "~/Documents/ClaDS_Julia/Julien/Cl2_jl.Rdata" ,
    sample_fraction = sampling_fraction, max_it_number = Inf)

@save "/Users/maliet/Documents/ClaDS_Julia/Julien/Cl2_jl.jld2" sampler
