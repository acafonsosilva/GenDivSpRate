include("load_ClaDS2_functions.jl")
reval("""library(RPANDA)
    tree_full=read.nexus("~/Documents/ENS/Taux/Hacket_MCC_100_CAT.nex")""")
@rget tree_full
tree = ape2Tree(tree_full)
plot_ClaDS(rasterize(tree), show_labels = false, options = ",type='p'")

reval("""
        load("~/Documents/ClaDS_Julia/empirical/birds_fs.Rdata")
        f_tips = c()
        for (sp in tree_full[[4]]){
            if ( !sp %in% species_samplingFrac[,2]){
                f_tips = c(f_tips,1)
            }else{
                f_tips = c(f_tips,species_samplingFrac[which(species_samplingFrac[,2]==sp),3])
            }
        }
    """)
@rget f_tips
fs = sample_fractions(tree, f_tips)

plot_ClaDS(tree,fs[2:end], ln = false)
R"par(mfrow=c(1,1))"

Random.seed!(1)

sampler = run_ClaDS_LTT(tree, 1, print_state = 1, max_node_number = 20_000,
    thin = 10, it_edge_tree = 1, it_rates = 1, f=f_tips,
    enhance_method = "MHrates",plot_chain = true,save_as_R=true,Rfile="~/Documents/ClaDS_Julia/empirical/birds_MHR_fs.Rdata",
    plot_tree=100, goal_gelman = 0., end_it = 10, initialize_rates = 0)

sampler = run_ClaDS_LTT(tree, 20, print_state = 1, max_node_number = 20_000,
    thin = 10, it_edge_tree = 1, it_rates = 1, f=f_tips,sampler=sampler[1],
    enhance_method = "MHrates",plot_chain = true,save_as_R=true,Rfile="~/Documents/ClaDS_Julia/empirical/birds_MHR_fs.Rdata",
    plot_tree=100, goal_gelman = 0., end_it = 400, initialize_rates = 0)

result = (tree, sampler, f_tips)
@save "/Users/maliet/Documents/Julia_ClaDS/bird1.jld2" result



sampler = run_ClaDS_LTT(tree, 20, print_state = 4, max_node_number = 20_000,
    thin = 10, it_edge_tree = 1, it_rates = 1, f=f_tips,sampler=sampler[1],
    enhance_method = "MHrates",plot_chain = true,save_as_R=true,Rfile="~/Documents/ClaDS_Julia/empirical/birds_MHR_fs.Rdata",
    plot_tree=100, goal_gelman = 0., end_it = 1000, initialize_rates = 0)
