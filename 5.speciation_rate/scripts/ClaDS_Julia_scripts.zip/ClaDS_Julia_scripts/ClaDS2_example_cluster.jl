include("load_ClaDS2_functions.jl")

R"library(RPANDA)"
R"data(Cetacea)"  #load the tree in R
@rget Cetacea     #load it in Julia
tree = ape2Tree(Cetacea)    # and make it a Julia Tree

Random.seed!(813)
n_iter = 400

sample_fraction = 87/89
sampler = run_ClaDS_LTT(tree, n_iter,plot_tree = 0,
    print_state = Int64(n_iter/4), plot_chain = false,
    f=sample_fraction, ltt_steps = 50)
#on the cluster, plot_tree should be set to 0 and plot_chain to false (the default values) so that nothing is plotted

sampler_to_Rdata(tree, sampler, "ClaDS2_Cetacea.Rdata" ; sample_fraction = sample_fraction, max_it_number = 2_500)
