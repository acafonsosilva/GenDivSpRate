include("load_ClaDS2_functions.jl")
reval("""library(RPANDA)
    tree_full=read.nexus("~/Documents/ENS/Taux/Hacket_MCC_100_CAT.nex")""")
@rget tree_full
tree = ape2Tree(tree_full)

reval("""
    load(paste0("~/Downloads/birds_MHR_fs.Rdata"))
    """)
@rget MAPS

chains = R_coda_to_chains("~/Downloads/birds_MHR_fs.Rdata")

npar = tree.n_nodes + 3


R"par(mfrow = c(1,2))"
plot_ClaDS(tree, MAPS[5:npar])

plot_LTT_chain(chains, tree, 20000,MAPS, n_ltt = 20)

sampler = (chains,tree);
plot_coda(sampler, burn = 1/4)

reval("""
    load(paste0("~/Downloads/birds_MHRQ_fs.Rdata"))
    """)
@rget MAPS

npar = tree.n_nodes + 3


R"par(mfrow = c(1,2))"
plot_ClaDS(tree, MAPS[5:npar])

#plot_LTT_chain(chains, tree, 20000,MAPS, n_ltt = 20)

sampler = (R_coda_to_chains("~/Downloads/birds_MHRQ_fs.Rdata"),tree);
plot_coda(sampler, burn = 1/4)
