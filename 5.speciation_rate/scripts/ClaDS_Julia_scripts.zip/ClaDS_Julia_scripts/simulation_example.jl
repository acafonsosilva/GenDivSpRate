using RCall
using StatsBase
using Distributions
using Random
using BenchmarkTools
using JLD2
include("Tree.jl")
include("sim_ClaDS.jl")
include("prune.jl")

# define simulation parameters
σ = 0.3     # stochasticity
α = 0.9     # trend
λ0 = 0.1    # initial speciation rate
ε = 0.5     # turnover rate
tr = 200    # root age
n = 100     # extant species number



# simulate a tree conditionned by the extant species number
Random.seed!(1)
extant_tree = sim_ClaDS2_ntips(n,σ,α,ε,λ0)

# the same tree, keeping the extinct lineages
Random.seed!(1)
complete_tree = sim_ClaDS2_ntips(n,σ,α,ε,λ0, prune_extinct = false)

# plot them
R"par(mfrow=c(1,2))"
plot_ClaDS(extant_tree)
plot_ClaDS(complete_tree)




# simulate a tree and stop at the first time it reaches a given species number
Random.seed!(1)
extant_tree = sim_ClaDS2_ntips_aux(n,σ,α,ε,λ0)

# the same tree, keeping the extinct lineages
Random.seed!(1)
complete_tree = sim_ClaDS2_ntips_aux(n,σ,α,ε,λ0, prune_extinct = false)

# plot them
R"par(mfrow=c(1,2))"
plot_ClaDS(extant_tree)
plot_ClaDS(complete_tree)




# simulate a tree conditionned by the root age
Random.seed!(1)
extant_tree = sim_ClaDS2_time(tr,σ,α,ε,λ0, prune_extinct = true)

Random.seed!(1)
complete_tree = sim_ClaDS2_time(tr,σ,α,ε,λ0, prune_extinct = false)

R"par(mfrow=c(1,2))"
plot_ClaDS(extant_tree)
plot_ClaDS(complete_tree)

# The same, conditionned also by the number of species staying below max_node_number
Random.seed!(1)
extant_tree = sim_ClaDS2_time(tr,σ,α,ε,λ0, prune_extinct = true, max_node_number = 100, return_if_max = false)

Random.seed!(1)
complete_tree = sim_ClaDS2_time(tr,σ,α,ε,λ0, prune_extinct = false,  max_node_number = 100, return_if_max = false)

R"par(mfrow=c(1,2))"
plot_ClaDS(extant_tree)
plot_ClaDS(complete_tree)






# finally, prune a tree keeping species with sampling probability f, conditionned
# by the fact that the crown age stays the same
pruned_tree, tip_rates = sample_tips_tipRates(extant_tree, 0.5, root_age = true)

R"par(mfrow=c(1,2))"
plot_ClaDS(extant_tree)
plot_ClaDS(pruned_tree)
