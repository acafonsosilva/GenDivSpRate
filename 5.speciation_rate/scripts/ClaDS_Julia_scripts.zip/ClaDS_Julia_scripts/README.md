# ClaDS2

This is the current version of the Julia code for ClaDS2 using data augmentation

## Lattest updates:

### tip labels

Importing phylogenies from R now allows to keep the tip labels, and you can display them when plotting the tree.

```{julia}
reval("""library(RPANDA)
        data(Cetacea)
    """)
    
@rget Cetacea

tree = ape2Tree(Cetacea)
plot_ClaDS(tree, show_labels = true)
```

### sampling fractions

It is now possible to have different sampling fractions for different subclades. For that you have to provide a vector with the value of the sampling fraction for each tip to the f argument in run_ClaDS_LTT, in the same order as the tip labels. It is still possible have a unique sampling fraction for the whole clade by passing a float to the f argument.


### limit to the number of iterations

The optional argument of run_ClaDS_LTT "end_it" allows to specify a maximum number of iterations for the run. Default to Inf.


### don't compute the gelman statistics

For very big trees (like the birds), computing the Gelman takes forever... To disable its computation, use goal_gelman = 0. as an argument in run_ClaDS_LTT. In taht case you need to remember to put a finite value for end_it, or it will never end.


### save in R while running the analysis

Once again usefull for big trees as it can run forever. For this set save_as_R to true (default to save_as_R = false), and Rfile to the desired Rdata name (default to Rfile = "coda.Rdata"). It saves the file every n_reccord iterations, which might be a bit to often, I could fix this.


### tip rates

In the formulation of the model the rates are defined at the beginning of the branch in the reconstructed phylogeny. However, when there is extinction or incomplete sampling, they can change between the begining and the end of a branch. When we enhance the tree with extinct lineages in the data augmentation procedure, we have access to the distribution of the rates at the end of the branch.

I now reccord them during the MCMC, and you can find them in the MAPS vector. From what I see on simulated trees the values are not super far from the values at the beginning of the tips so it shouldn't change results much.

```{R}
MAPS[(nedges+5):(nedges+4+ntips)]
```

## How to set up an analysis 

Here an example with the Cetacea phylogeny.

First, load all the needed functions and classes

```{julia}
include("load_ClaDS2_functions.jl")
```

### Importing the tree

Load the tree in R, import it in Julia and convert it to a Tree object (with tip labels ;) ).

```{julia}
reval("""library(RPANDA)
        data(Cetacea)
    """)
    
@rget Cetacea

tree = ape2Tree(Cetacea)
plot_ClaDS(tree, show_labels = true)
```

### Running ClaDS

```{julia}
Random.seed!(813)
sample_fraction = 85/87

sampler = run_ClaDS_LTT(tree, 400, print_state = 100, 
        max_node_number = 5_000, thin = 10, burn = 0.1,
        it_edge_tree = 1, it_rates = 1, enhance_method = "MHrates",
        plot_chain = false, plot_tree=0, f=sample_fraction)
```

I still need to decide what to put as default argument, but those proposed here I think are good options. The augmentation is done slightly differently than what was proposed on the owncloud. I think it leads to less efficient mixing but it should help for big trees as there is much less rejection.

To have different sampling fractions for different subclade, you need to replace the f argument with a vector with the value of the sampling fraction for each tip in the same order as the tip labels.


### Plot the results in Julia

```{julia}
sampler = result[2]
tree = result[1]
MAPS = sampler[2]
npar = tree.n_nodes + 3

R"par(mfrow = c(1,2))"
plot_ClaDS(tree, map(exp, MAPS[5:npar]))
plot_LTT_chain(sampler, tree, npar, n_ltt = 100)
```

### Save and export in R

```{julia}
sampler_to_Rdata(tree, sampler, "ClaDS2_Cetacea.Rdata" ; sample_fraction = sample_fraction)
```


### The MAPS vector

The MAPS vector saved in the Rdata file with the sampler_to_Rdata function contains the maxima a posterior for the following elements i respective position:

position              | parameter
---------------------------- | ---------------------
1                 | $\sigma$, the stochasticity parameter
2                 | $\alpha$, the trend parameter
3                 | $\varepsilon$, the turnover rate
4                 | $\lambda_0$, the initial speciation rate
5 to (nedges + 4)  | $\lambda_i$, the branch specific speciation rates associated to the edges of the reconstructed tree
(nedges + 5) to (nedges + ntips + 4)  | the tip rates
(nedges + ntips + 5)  | number of extinct species
(nedges + ntips + 7)  | number of species at present time, including the unsampled ones
(nedges + ntips + 7) to (nedges + ntips + ltt_steps + 7)  | the number of lineages through time at time points that are regularly spaced between the root and the present

Note: ltt_steps is not saved in the Rdata file. The default value is 50.