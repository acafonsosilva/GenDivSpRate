include("load_ClaDS2_functions.jl")
include("load_ETR2.jl")

R"library(RPANDA)"
R"data(Cetacea)"
@rget Cetacea
tree = ape2Tree(Cetacea)

plot_ClaDS(tree)
Random.seed!(813)
n_iter = 1
n = tree.n_nodes
npar = n +3
root_depth = maximum(node_depths(tree)) * 1.01
live_nd = node_depths_base(tree)
println(root_depth)
ltt_times = [0:50...] * root_depth/50
ltt_extant = LTT(tree,ltt_times)
n=100
ini_par = [[[1,1,0.5];fill(0.000001, tree.n_nodes);
    fill(0.000001, Int64((tree.n_nodes+1)/2));[0, n_extant_tips(tree)] ;
    ltt_extant[2]] for i in 1:n]

R"par(mar = c(3,3,0,0))"
sample_fraction = 87/89
sampler_ETR2 = run_ClaDS_ETR2(tree, n_iter,plot_tree = 0, it_rates = 1, it_edge_tree = 20,thin = 1,max_node_number = 50,
    print_state = 0, plot_chain = true, initialize_rates = 0,max_try = 100_000, burn = 0.1,
    f=87/89, ltt_steps = 50, end_it = 100_000, n_chains = n, ini_par = ini_par)

chain = sampler[1][1]
g = gelman(chain,npar, burn = 1/10)
(maximum(g))
maxi
println(g)
result = (tree, sampler, sample_fraction)
#@save "Example_Ceatacea.jld2" result


#plot the result in Julia
#@load "Example_Ceatacea.jld2" result
sampler = result[2]
tree = result[1]
MAPS = sampler[2]
npar = tree.n_nodes + 3

R"par(mfrow = c(1,2))"
plot_ClaDS(tree, map(exp, MAPS[5:npar]))
plot_LTT_chain(sampler, tree, npar, n_ltt = 100)

l1 = LTT(tree,sampler[[1]][1][3][3], sampler[2])
l2 = LTT(graft_edge_trees(tree,sampler[[1]][1][3][3]), sampler[2])

l1[2] - l2[2]
#save the results as a Rdata file
@load "Example_Ceatacea.jld2" result
sampler = result[2]
tree = result[1]
sample_fraction = result[3]
sampler_to_Rdata(tree, sampler, "ClaDS2_Cetacea.Rdata" ; sample_fraction = sample_fraction)

#=
You can save only a predefined number of iteration per chain by setting the parameter max_it_number in
sampler_to_Rdata (default to Inf)
=#
