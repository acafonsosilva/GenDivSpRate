println("starting")
include("load_ClaDS2_functions.jl")
println("started")

seed = 813
ε = 0.5
σ = 0.3
mean_rate = 0.9
α = mean_rate / exp(σ^2/2)
n_tips = 10
λ0 = 0.1
println(" ")
println("σ = $σ, α = $α, ε = $ε ; seed = $seed")

seed = seed

Random.seed!(seed)

tree = sim_ClaDS2_time(550,σ,α,ε,λ0,max_node_number=50)
plot_ClaDS(tree)


tree, complete_tree, times, n_lineages, end_time = sim_ClaDS2_ntips(n_tips,σ,α,ε,λ0, prune_extinct = false)
Random.seed!(seed)
tree, extant_tree, times, n_lineages, end_time = sim_ClaDS2_ntips(n_tips,σ,α,ε,λ0, prune_extinct = true)
speciation_rates = extract_rates(extant_tree)

R"par(mfrow=c(1,3), mar = c(8,2,3,3))"
plot_ClaDS(complete_tree)
plot_ClaDS(extant_tree)

fs = [fill(0.5,3); fill(0.2,5); fill(1.,2)]
sample_fractions(extant_tree, fs)
plot_ClaDS(extant_tree,sample_fractions(extant_tree, fs)[2:(end-0)])
n_iter = 400
sampler = run_ClaDS_LTT(extant_tree, n_iter, print_state = 100, max_node_number = 5_000, thin = 10,
    it_edge_tree = 1, it_rates = 1, enhance_method = "MHrates",plot_chain = true,plot_tree=100, f = fs)

R"par(mfrow=c(1,3), mar = c(8,2,3,3))"
plot_ClaDS(extant_tree)
plot_ClaDS(extant_tree, map(exp,sampler[2][5:(extant_tree.n_nodes+3)]))




tree = ape2Tree(Cetacea)
tree_r=rasterize(tree)

R"par(mfrow = c(1,2))"
plot_ClaDS(tree, show_labels = true)
plot_ClaDS(tree_r, show_labels = true)
